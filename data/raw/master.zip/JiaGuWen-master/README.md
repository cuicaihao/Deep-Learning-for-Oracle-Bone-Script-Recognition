# 甲骨文数据库

提供甲骨文数据库，汉字与对应的图片。

<img width="1431" alt="截屏" src="https://user-images.githubusercontent.com/7275046/73815692-abb35a00-4821-11ea-8622-8b6fec0ac0dc.png">

## License

[MIT](https://renyuzhuo.cn/MIT)

## 捐赠

点击[这里](https://renyuzhuo.cn/donate)
